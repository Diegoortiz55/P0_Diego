drop table tbl_TransactionsInfo
drop table tbl_AccountInfo
drop table tbl_LoginInfo

create table tbl_LoginInfo
(
    userName varchar(30),
    userPwd varchar(12) not null default 'password1234',
    accountStatus varchar(20) default 'Active',
    userType varchar(20) not null default 'User',
    LoginAttempts int default 0,
    constraint pk_userName primary key(userName),
    constraint chk_userPwd_len check(len(userPwd) > 5),
    constraint chk_accountStatus_list check (accountStatus in ('Active', 'Disabled')), 
    constraint chk_userType_list check (userType in ('User', 'Administrator'))
) 

create table tbl_AccountInfo
(
    accNo int,
    accName varchar(20),
    accType varchar(20) not null, 
    accBalance float not null,
    accEmail varchar(30) not null,
    constraint pk_accNo primary key(accNo),
    constraint fk_accEmail foreign key(accEmail) references tbl_LoginInfo,
    constraint chk_accType_list check(accType in('Checking', 'Savings')),
    constraint chk_accBalance check (accBalance > 100),
)
create table tbl_TransactionsInfo
(
    tranID int identity,
    tranDate DATETIME,
    tranType varchar(20) not null,
    fromAccount int,
    toAccount int,
    tranAmount int,
    completedBy varchar(30),
    constraint fk_fromAccount foreign key(fromAccount) references tbl_AccountInfo,
    constraint fk_toAccounts foreign key(toAccount) references tbl_AccountInfo,
    constraint f_completedBy foreign key(completedBy) references tbl_LoginInfo
)


delete from tbl_LoginInfo where userName = 'administrator@prbank.com'
insert into tbl_LoginInfo(userName, userPwd, userType) values ('Administrator@PRcu.com', 'Admin1234', 'Administrator')
insert into tbl_AccountInfo values (101, 'Diego', 'Checking', 2000,'DiegoOG@yahoo.com')
insert into tbl_AccountInfo values (102, 'Diego', 'Savings', 5000,'DiegoOG@yahoo.com')
insert into tbl_LoginInfo(userName, userPwd, userType) values ('DiegoOG@yahoo.com', 'passw@rd0987', 'User')
select * from tbl_TransactionsInfo 
select * from tbl_AccountInfo
select * from tbl_LoginInfo
Select count(*) from tbl_AccountInfo join tbl_LoginInfo on tbl_AccountInfo.accEmail=tbl_LoginInfo.userName where accEmail='DiegoOG@yahoo.com'
update tbl_LoginInfo set accountStatus='Active', LoginAttempts=0 where userName='DiegoOG@outlook.com'
update tbl_LoginInfo set userName='DiegoOG@yahoo.com' where userName='DiegoOG@outlook.com'
Select * from tbl_AccountInfo join tbl_LoginInfo on tbl_AccountInfo.accEmail=tbl_LoginInfo.userName where accNo = 101
Select count(*) from tbl_AccountInfo join tbl_LoginInfo on tbl_AccountInfo.accEmail=tbl_LoginInfo.userName where accNo=101
update tbl_AccountInfo set accBalance=accBalance-250 where accNo=101;insert into tbl_TransactionsInfo(calender,fromAccount,amount) values(GETDATE(),101,250);select accBalance from tbl_AccountInfo where accNo=101
select top 10 * from tbl_TransactionsInfo join tbl_AccountInfo on tbl_TransactionsInfo.completedBy=accEmail where accNo=102
Select count(*) from tbl_AccountInfo join tbl_LoginInfo on tbl_AccountInfo.accEmail=tbl_LoginInfo.userName where accNo=104 and accEmail='diegoog@yahoo.com'
