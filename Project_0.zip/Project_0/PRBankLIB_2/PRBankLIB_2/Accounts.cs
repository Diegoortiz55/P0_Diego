﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;


namespace PRBankLIB_2
{
        public class Accounts
        {
            public int accNo { get; set; }
            public string accName { get; set; }
            public double accBalance { get; set; }
            public string accType { get; set; }
            public string accEmail { get; set; }
            

            SqlConnection con = new SqlConnection(@"server=localhost;database=BankingDB;user id=sa;password=Strong.Pwd-123");

            #region Create Accounts
            public string AddAccount(Accounts p_accObj)
            {
                SqlCommand cmdNewAccount = new SqlCommand("if not exists (select userName from tbl_LoginInfo where userName=@aEmail) insert into tbl_loginInfo(userName) values(@aEmail);insert into tbl_AccountInfo values(@aNo,@aName,@aType,@aBalance,@aEmail);", con);
                cmdNewAccount.Parameters.AddWithValue("@aNo", p_accObj.accNo);
                cmdNewAccount.Parameters.AddWithValue("@aName", p_accObj.accName);
                cmdNewAccount.Parameters.AddWithValue("@aType", p_accObj.accType);
                cmdNewAccount.Parameters.AddWithValue("@aBalance", p_accObj.accBalance);
                cmdNewAccount.Parameters.AddWithValue("@aEmail", p_accObj.accEmail);
                con.Open();
                int recordsAffected = cmdNewAccount.ExecuteNonQuery();
                con.Close();
                return "New Account Created";
            }
            #endregion

            #region Check if Accounts Exists for Admin
            public bool adminCheckAccountExists(int p_accNo)
            {
            SqlCommand cmdCheck = new SqlCommand("Select count(*) from tbl_AccountInfo where accNo=@aNo", con);
            cmdCheck.Parameters.AddWithValue("@aNo", p_accNo);
            con.Open();
            int count = (int)cmdCheck.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
            }
            #endregion

            #region Check If Account Exists for Customer
            public bool checkAccountExists(int p_accNo, string p_accEmail)
            {
                SqlCommand cmdCheck = new SqlCommand("Select count(*) from tbl_AccountInfo join tbl_LoginInfo on tbl_AccountInfo.accEmail=tbl_LoginInfo.userName where accNo=@aNo and accEmail=@aEmail", con);
                cmdCheck.Parameters.AddWithValue("@aNo", p_accNo);
                cmdCheck.Parameters.AddWithValue("@aEmail", p_accEmail);
                con.Open();
                int count = (int)cmdCheck.ExecuteScalar();
                con.Close();
                if (count == 1)
                {
                    return true;
                }
                return false;
            }
            #endregion

            #region View Account Details
            public Accounts GetAccountDetails(int p_accNo)
            {
                SqlCommand cmdGetAccountDetails = new SqlCommand("Select * from tbl_AccountInfo where accNo=@aNo", con);
                cmdGetAccountDetails.Parameters.AddWithValue("@aNo", p_accNo);
                con.Open();
                SqlDataReader readAcc = cmdGetAccountDetails.ExecuteReader();
                Accounts accDetail = new Accounts();
                if (readAcc.Read())
                {
                    accDetail.accNo = Convert.ToInt32(readAcc[0]);
                    accDetail.accName = readAcc[1].ToString();
                    accDetail.accType = readAcc[2].ToString();
                    accDetail.accBalance = (double)readAcc[3];
                    accDetail.accEmail = readAcc[4].ToString();
                }
                else
                {
                    readAcc.Close();
                    con.Close();
                    throw new Exception("Account not found");
                }
                readAcc.Close();
                con.Close();
                return accDetail;
            }
            #endregion

            #region Check Balance
            public double CheckBalance(int p_accNo)
            {
                SqlCommand cmdCheckBalance = new SqlCommand("select accBalance from tbl_AccountInfo where accNo=@aNo;", con);
                cmdCheckBalance.Parameters.AddWithValue("@aNo", p_accNo);
                con.Open();
                double chkAccBalance = (double)cmdCheckBalance.ExecuteScalar();
                con.Close();
                return chkAccBalance;
            }
            #endregion
    }
}



