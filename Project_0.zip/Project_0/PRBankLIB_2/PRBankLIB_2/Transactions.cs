﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Data.SqlClient;
namespace PRBankLIB_2
{
    public class Transactions : Accounts
    {
                public int tranID { get; set; }
                public DateTime tranDate { get; set; }
                public string tranType { get; set; }
                public int fromAccount { get; set; }
                public int toAccount { get; set; }
                public int tranAmount { get; set; }
                public string completedBy { get; set; }

        SqlConnection con = new SqlConnection(@"server=localhost;database=BankingDB;user id=sa;password=Strong.Pwd-123");

        #region Perform Withdrawal
        public int Withdraw(Transactions p_accObj, double p_withdrawAmt)
        {
            SqlCommand cmdWithdraw = new SqlCommand("update tbl_AccountInfo set accBalance=accBalance-@wAmount where accNo=@aNo;insert into tbl_TransactionsInfo(tranDate,tranType,fromAccount,tranAmount,completedBy) values(GETDATE(),'Withdrawal',@fromAccount,@wdAmount,@completedBy);select accBalance from tbl_AccountInfo where accNo=@aNo", con);
            cmdWithdraw.Parameters.AddWithValue("@wAmount", p_withdrawAmt);
            cmdWithdraw.Parameters.AddWithValue("@aNo", p_accObj.accNo);
            cmdWithdraw.Parameters.AddWithValue("@fromAccount", p_accObj.accNo);
            cmdWithdraw.Parameters.AddWithValue("@wdAmount", p_withdrawAmt);
            cmdWithdraw.Parameters.AddWithValue("@completedBy", p_accObj.accEmail);
            con.Open();
            double newAccBalance = (double)cmdWithdraw.ExecuteScalar();
            con.Close();
            return (int)newAccBalance;
        }
        #endregion

        #region Perform Deposit
        public double Deposit(Transactions p_accObj, double p_depositAmt)
        {
            SqlCommand cmdDeposit = new SqlCommand("update tbl_AccountInfo set accBalance=accBalance+@dAmount where accNo=@aNo;insert into tbl_TransactionsInfo(tranDate,tranType,toAccount,tranAmount,completedBy) values(GETDATE(),'Deposit',@toAccount,@dpAmount,@completedBy);select accBalance from tbl_AccountInfo where accNo=@aNo", con);
            cmdDeposit.Parameters.AddWithValue("@dAmount", p_depositAmt);
            cmdDeposit.Parameters.AddWithValue("@aNo", p_accObj.accNo);
            cmdDeposit.Parameters.AddWithValue("@toAccount", p_accObj.accNo);
            cmdDeposit.Parameters.AddWithValue("@dpAmount", p_depositAmt);
            cmdDeposit.Parameters.AddWithValue("@completedBy", p_accObj.accEmail);
            con.Open();
            double newAccBalance = (double)cmdDeposit.ExecuteScalar();
            con.Close();
            return (int)newAccBalance;
        }
        #endregion

        #region Perform Transfer
        public string Transfer(Transactions p_accObj, int p_fromAcc, int p_toAccount, double p_amount)
        {
            SqlCommand cmdFrom = new SqlCommand("update tbl_AccountInfo set accBalance=accBalance-@tranAmount where accNo=@fromAccount", con);
            cmdFrom.Parameters.AddWithValue("@tranAmount", p_amount);
            cmdFrom.Parameters.AddWithValue("@fromAccount", p_fromAcc);

            SqlCommand cmdTo = new SqlCommand("update tbl_AccountInfo set accBalance=accBalance+@tranAmount where accNo=@toAccount", con);
            cmdTo.Parameters.AddWithValue("@tranAmount", p_amount);
            cmdTo.Parameters.AddWithValue("@toAccount", p_toAccount);

            SqlCommand cmdTransaction = new SqlCommand("insert into tbl_TransactionsInfo values(GETDATE(),'Transfer',@fromAccount,@toAccount,@tranAmount,@completedBy)", con);
            cmdTransaction.Parameters.AddWithValue("@fromAccount", p_fromAcc);
            cmdTransaction.Parameters.AddWithValue("@toAccount", p_toAccount);
            cmdTransaction.Parameters.AddWithValue("@tranAmount", p_amount);
            cmdTransaction.Parameters.AddWithValue("@completedBy", p_accObj.accEmail);

            con.Open();
            cmdFrom.ExecuteNonQuery();
            cmdTo.ExecuteNonQuery();
            cmdTransaction.ExecuteNonQuery();
            con.Close();

            return "Transfer Successful";
        }
        #endregion

        #region View Last Transactions
        public List<Transactions> GetTransactionHistory(Accounts p_accObj)
        {
            SqlCommand cmdGetTransactionHistory = new SqlCommand("select top 10 tranID,tranDate,tranType,fromAccount,toAccount,tranAmount,completedBy from tbl_TransactionsInfo join tbl_AccountInfo on tbl_TransactionsInfo.completedBy=accEmail where accNo=@aNo", con);
            cmdGetTransactionHistory.Parameters.AddWithValue("@aNo", p_accObj.accNo);
            con.Open();
            SqlDataReader readTran = cmdGetTransactionHistory.ExecuteReader();
            List<Transactions> transList = new List<Transactions>();
            while (readTran.Read())
            {
                transList.Add(new Transactions
                {
                    tranID = Convert.ToInt32(readTran[0]),
                    tranDate = Convert.ToDateTime(readTran[1]),
                    tranType = Convert.ToString(readTran[2]),
                    fromAccount = (readTran[3]) as int? ?? default(int),
                    toAccount = (readTran[4]) as int? ?? default(int),
                    tranAmount = Convert.ToInt32(readTran[5]),
                    completedBy = Convert.ToString(readTran[6])
                });
            }
            readTran.Close();
            con.Close();
            return transList;
        }
        #endregion
    }
}

