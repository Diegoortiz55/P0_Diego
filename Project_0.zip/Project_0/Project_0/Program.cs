﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using LoginLIB;
using PRBankLIB_2;
using System.Data.SqlClient;


namespace Project_0
{
    class Program
    {

        static void Main(string[] args)
        {
            #region Welcome Menu
                WelcomeMenu:
                Console.Clear();
                Console.WriteLine(" Welcome to Puerto Rico Credit Union ");
                Console.WriteLine(" Please Choose Login Type ");
                Console.WriteLine("1. Administrator ");
                Console.WriteLine("2. User ");
                Console.WriteLine("3. Exit ");
                LogInType logObj = new LogInType(); //used for calling methods from LogIn
                LogInType newLog = new LogInType(); //used for updating LogIn records 
                Accounts accObj = new Accounts(); //used for calling methods from Accounts
                Accounts accUpd = new Accounts(); //used for updating Accounts records
                Transactions tranObj = new Transactions(); //used for calling methods from Transactions
                Accounts newAcc = new Transactions(); //used for performing transactions with properties from Accounts


            #endregion
            #region Adminstrator Login and Menu
            int LogIn = Convert.ToInt32(Console.ReadLine());
                switch (LogIn)
                {
                    case 1:
                        AdminLogin:
                        Console.WriteLine(" Please Enter Username.");
                        string v_adminName = Console.ReadLine();
                            if (string.IsNullOrEmpty(v_adminName))
                            {
                                //Console.Clear();
                                Console.WriteLine("No input from the user was recorded. Please input your username.");
                                goto AdminLogin;
                            }
                        AdminPassword:
                        Console.WriteLine(" Please Enter Password ");
                        string v_adminPwd = Console.ReadLine();
                            if (string.IsNullOrEmpty(v_adminPwd))
                            {
                                Console.WriteLine("No input from the user was recorded. Please input your password.");
                                goto AdminPassword;
                            }
                        newAcc.accEmail = v_adminName; //used to tie admin account to transactions
                        bool logInResult = logObj.CheckAdminCredentials(v_adminName, v_adminPwd);
                        bool continueAPP = false;

                        if (logInResult == true)
                        {
                            continueAPP = true;
                        }
                        else
                        {
                            Console.WriteLine(" Invalid Credentials. Please try again. ");
                            Console.ReadLine();
                            goto WelcomeMenu;
                        }
                        while (continueAPP == true)
                        {
                        try
                        { 
                            Console.Clear();
                            Console.WriteLine("1. Create a new account ");
                            Console.WriteLine("2. View Customer Account Details ");
                            Console.WriteLine("3. Perform Withdrawal ");
                            Console.WriteLine("4. Perform Deposit ");
                            Console.WriteLine("5. Transfer Funds ");
                            Console.WriteLine("6. Disable an Account ");
                            Console.WriteLine("7. Activate an Account ");
                            Console.WriteLine("8. Exit ");

                            int AdminMenu = Convert.ToInt32(Console.ReadLine());
                            bool check = false;

                            switch (AdminMenu)
                            {
                                #region Case 1 : Create Account
                                case 1:
                                    try
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Please Enter Account Number. ");
                                        accUpd.accNo = Convert.ToInt32(Console.ReadLine());

                                        check = accObj.adminCheckAccountExists(accUpd.accNo);
                                        if (!check)
                                        {
                                            Console.WriteLine("Please Enter Account Name. ");
                                            accUpd.accName = Console.ReadLine();
                                            if (string.IsNullOrEmpty(accUpd.accName))
                                            {
                                                throw new Exception("No input from the user was recorded. Please input account holder's name.");
                                            }
                                            Console.WriteLine("Enter Account Type. ");
                                            accUpd.accType = Console.ReadLine();
                                            if (accUpd.accType != "Checking" && accUpd.accType != "Savings")
                                            {
                                                throw new Exception("Account must be a Checking or Savings.");
                                            }
                                            Console.WriteLine("Please Enter Initial Bank Account Balance. ");
                                            accUpd.accBalance = Convert.ToInt32(Console.ReadLine()); ;
                                            if (accUpd.accBalance < 100)
                                            {
                                                throw new Exception("Initial account balance must exceed $100");
                                            }
                                            Console.WriteLine("Please Enter Account Email. ");
                                            accUpd.accEmail = Console.ReadLine();
                                            if (string.IsNullOrEmpty(accUpd.accEmail))
                                            {
                                                throw new Exception("No input from the user was recorded. Please input account holder's email.");
                                            }
                                            string result = accObj.AddAccount(accUpd); 
                                            Console.WriteLine(result);
                                            Console.ReadLine();
                                        }
                                        else
                                        {
                                            Console.WriteLine("Account already exists. Please enter a different account number.");
                                        }
                                    }
                                    catch (Exception ex1)
                                    {
                                        Console.WriteLine(ex1.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 2 : View Account Details
                                case 2:
                                    try
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Please Enter Customer's Account Number.");
                                        newAcc.accNo = Convert.ToInt32(Console.ReadLine());

                                        check = accObj.adminCheckAccountExists(newAcc.accNo);
                                        if (check)
                                        {
                                            Accounts accDetails = accObj.GetAccountDetails(newAcc.accNo);
                                            Console.WriteLine("Customer Name is: " + accDetails.accName);
                                            Console.WriteLine("Customer Email is: " + accDetails.accEmail);
                                            Console.WriteLine("Customer Account Number is: " + accDetails.accNo);
                                            Console.WriteLine("Customer Account Type is: " + accDetails.accType);
                                            Console.WriteLine("Customer Account Balance is: " + "$" + accDetails.accBalance);
                                            Console.WriteLine("--------------------------------------------------");
                                            Console.ReadLine();
                                        }
                                        else
                                        {
                                            throw new Exception("Account not found.");
                                        }
                                    }
                                    catch (Exception ex2)
                                    {
                                        Console.WriteLine(ex2.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 3 : Perform Withdrawal
                                case 3:
                                    try
                                    { 
                                    Console.Clear();
                                    Console.WriteLine("Please Enter Customer's Account Number.");
                                    newAcc.accNo = Convert.ToInt32(Console.ReadLine());

                                    check = accObj.adminCheckAccountExists(newAcc.accNo);
                                    if (check)
                                    {
                                        double chkBalance = accObj.CheckBalance(newAcc.accNo);
                                        Console.WriteLine("Customer's Current Balance is: " + "$" + chkBalance);
                                        Console.WriteLine("Please Enter Amount Customer Wishes To Withdraw.");
                                        double v_withdrawAmt = Convert.ToInt32(Console.ReadLine());
                                        if (v_withdrawAmt > chkBalance)
                                        {
                                            throw new Exception("Insufficient Funds to Process Transaction.");
                                        }
                                        if (v_withdrawAmt <= 0)
                                        {
                                            throw new Exception("Unable to process transaction. Must withdraw more than $0");
                                        }
                                        if (v_withdrawAmt < chkBalance && v_withdrawAmt > 2000)
                                        {
                                            throw new Exception("Unable to process transaction. Withdrawal limit is $2000");
                                        }
                                        double newAmt = tranObj.Withdraw((Transactions)newAcc, v_withdrawAmt);
                                        Console.WriteLine("Withdrawal Successful. Customer's New Account balance is: " + "$" + newAmt);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        throw new Exception("Account not found. Please re-enter account number.");
                                    }
                                    }
                                    catch (Exception ex3)
                                    {
                                        Console.WriteLine(ex3.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 4 : Perform Deposit
                                case 4:
                                    try
                                    { 
                                    Console.Clear();
                                    Console.WriteLine("Please Enter Customer's Account Number.");
                                    newAcc.accNo = Convert.ToInt32(Console.ReadLine());

                                    check = accObj.adminCheckAccountExists(newAcc.accNo);
                                    if (check)
                                    {
                                        double chkBalance = accObj.CheckBalance(newAcc.accNo);
                                        Console.WriteLine("Customer's Current Balance is: " + "$" + chkBalance);
                                        Console.WriteLine("Please Enter Amount Customer Wishes to Deposit.");
                                        double v_depositAmt = Convert.ToInt32(Console.ReadLine());
                                        if (v_depositAmt <= 0)
                                        {
                                            throw new Exception("Unable to process transaction. Must deposit more than $0");
                                        }
                                        double newAmt = tranObj.Deposit((Transactions)newAcc, v_depositAmt);
                                        Console.WriteLine("Deposit Successful. Customer's New Account balance is: " + "$" + newAmt);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        Console.WriteLine("Account not found. Please re-enter account number.");
                                    }
                                    }
                                    catch (Exception ex4)
                                    {
                                        Console.WriteLine(ex4.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 5 : Transfer Funds
                                case 5:
                                    try
                                    { 
                                    Console.WriteLine("Which Account Would the Customer Like to Transfer From? ");
                                    int v_fromAcc = Convert.ToInt32(Console.ReadLine());

                                    check = accObj.adminCheckAccountExists(v_fromAcc);
                                    if (check)
                                    {
                                        double chkBalance = accObj.CheckBalance(v_fromAcc);
                                        Console.WriteLine("Customer's current Balance is: " + "$" + chkBalance);
                                        Console.WriteLine("Which Account Would the Customer Like to Transfer To?");
                                        int v_toAcc = Convert.ToInt32(Console.ReadLine());
                                        check = accObj.adminCheckAccountExists(v_toAcc);
                                        if (check)
                                        {
                                            double chkBalance2 = accObj.CheckBalance(v_toAcc);
                                            Console.WriteLine("Customer's Current Balance is: " + "$" + chkBalance2);
                                            Console.WriteLine("Please Enter Amount Customer Wishes to Transfer?");
                                            int v_amount = Convert.ToInt32(Console.ReadLine());
                                            if (v_amount > chkBalance)
                                            {
                                                throw new Exception("Insufficient Funds to Process Transaction");
                                            }
                                            if (v_amount <= 0)
                                            {
                                                throw new Exception("Unable to process transaction. Must transfer more than $0");
                                            }
                                            string tranAcc = tranObj.Transfer((Transactions)newAcc, v_fromAcc, v_toAcc, v_amount);
                                            Console.WriteLine(tranAcc);
                                            Console.ReadLine();
                                        }
                                        else
                                        {
                                            throw new Exception("Account not found. Please ensure account number is correct and re-enter");
                                        }
                                    }
                                    else
                                    {
                                        throw new Exception("Account not found. Please ensure account number is correct and re-enter");
                                    }
                                    }
                                    catch (Exception ex5)
                                    {
                                        Console.WriteLine(ex5.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 6 : Disable Account
                                case 6:
                                    try
                                    { 
                                    Console.Clear();
                                    Console.WriteLine("Please Enter Account Username to Disable.");
                                    newLog.userName = Console.ReadLine();
                                        if (string.IsNullOrEmpty(newLog.userName))
                                        {
                                            throw new Exception("No input from the user was recorded. Please input customer's username.");
                                        }
                                        check = logObj.checkUserExists(newLog.userName);
                                    if (check)
                                    {
                                        string disable = logObj.DisableAccount(newLog);
                                        Console.WriteLine(disable);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        Console.WriteLine("Account not found. Please re-enter user name.");
                                    }
                                    }
                                    catch (Exception ex6)
                                    {
                                        Console.WriteLine(ex6.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 7 : Activate Account
                                case 7:
                                    try
                                    { 
                                    Console.Clear();
                                    Console.WriteLine("Please Enter Account Username to Activate.");
                                    newLog.userName = Console.ReadLine();
                                        if (string.IsNullOrEmpty(newLog.userName))
                                        {
                                            throw new Exception("No input from the user was recorded. Please input customer's username.");
                                        }
                                    check = logObj.checkUserExists(newLog.userName);
                                    if (check)
                                    {
                                        string enable = logObj.EnableAccount(newLog);
                                        Console.WriteLine(enable);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        throw new Exception("Account not found. Please re-enter user name.");
                                    }
                                    }
                                    catch (Exception ex7)
                                    {
                                        Console.WriteLine(ex7.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 8 : Exit
                                case 8:
                                    Console.WriteLine(" Thank You for Working Diligently For us, Goodbye. ");
                                    continueAPP = false;
                                    goto WelcomeMenu;
                                #endregion
                                default:
                                    Console.WriteLine("That is Not a Valid Choice.");
                                    Console.ReadLine();
                                    Console.Clear();
                                    break;
                            }
                            Console.ReadLine();
                            Console.Clear();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        }
                    break;
                #endregion
            #region User Login and Menu
                case 2:
                        UserLogin:
                        Console.WriteLine("Please Enter Username.");
                        string v_userName = Console.ReadLine();
                        if (string.IsNullOrEmpty(v_userName))
                        {
                        Console.Clear();
                        Console.WriteLine("No input from the user was recorded. Please input your username.");
                            goto UserLogin;
                        }
                        UserPassword:
                        Console.WriteLine("Please Enter Password ");
                        string v_userPwd = Console.ReadLine();
                        if (string.IsNullOrEmpty(v_userPwd))
                        {
                            Console.WriteLine("No input from the user was recorded. Please input your password.");
                            goto UserPassword;
                        }

                        newAcc.accEmail = v_userName; //used to tie user to accounts and transactions
                        bool continueAPP2 = false;
                        string logInResult2 = logObj.CheckUserCredentials(v_userName, v_userPwd);
                        Console.WriteLine(logInResult2);
                        if (logInResult2.Contains("Successful"))
                        {
                            continueAPP2 = true;
                        }
                        else
                        {
                            Console.ReadLine();
                            goto WelcomeMenu;
                        }
                    while (continueAPP2 == true)
                    {
                        try
                        {
                            Console.Clear();
                            Console.WriteLine("1. Check Account Balance ");
                            Console.WriteLine("2. Withdraw Funds ");
                            Console.WriteLine("3. Deposit Funds ");
                            Console.WriteLine("4. Transfer Funds ");
                            Console.WriteLine("5. View last 10 Transactions ");
                            Console.WriteLine("6. Change Password ");
                            Console.WriteLine("7. Exit ");
                            
                            int UserMenu = Convert.ToInt32(Console.ReadLine());
                            bool check = false;

                            switch (UserMenu)
                            {
                                #region Case 1 : Check Account Balance
                                case 1:
                                    try
                                    { 
                                        Console.WriteLine("Please Enter Your Account Number.");
                                        newAcc.accNo = Convert.ToInt32(Console.ReadLine());
                                        check = accObj.checkAccountExists(newAcc.accNo, newAcc.accEmail);
                                        if (check)
                                        {
                                        double chkBalance = accObj.CheckBalance(newAcc.accNo);
                                        Console.WriteLine("Your Account Balance is: " + "$" + chkBalance);
                                        Console.ReadLine();
                                        }
                                        else
                                        {
                                            throw new Exception("Account not found. Please re-enter account number.");
                                        }
                                    }
                                    catch (Exception es)
                                    {
                                        Console.WriteLine(es.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 2 : Perform Withdrawal
                                case 2:
                                    try
                                    {
                                    Console.Clear();
                                    Console.WriteLine("Please Enter Your Account Number.");
                                    newAcc.accNo = Convert.ToInt32(Console.ReadLine());

                                    check = accObj.checkAccountExists(newAcc.accNo, newAcc.accEmail);
                                    if (check)
                                    {
                                        double chkBalance = accObj.CheckBalance(newAcc.accNo);
                                        Console.WriteLine("Current balance is: " + "$" + chkBalance);
                                        Console.WriteLine("Please Enter Amount You Wish to Withdraw");
                                        double v_withdrawAmt = Convert.ToInt32(Console.ReadLine());
                                        if (v_withdrawAmt > chkBalance)
                                        {
                                            throw new Exception("Insufficient Funds to Process Transaction.");
                                        }
                                        if (v_withdrawAmt <= 0)
                                        {
                                            throw new Exception("Unable to process transaction. Must withdraw more than $0");
                                        }
                                        if (v_withdrawAmt < chkBalance && v_withdrawAmt > 2000)
                                        {
                                            throw new Exception("Unable to process transaction. Withdrawal limit is $2000");
                                        }
                                        double newAmt = tranObj.Withdraw((Transactions)newAcc, v_withdrawAmt);
                                        Console.WriteLine("Withdrawal successful. Your new account balance is: " + "$" + newAmt);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        throw new Exception("Account not found. Please re-enter account number.");
                                    }
                                    }
                                    catch (Exception es2)
                                    {
                                        Console.WriteLine(es2.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 3 : Perform Deposit
                                case 3:
                                    try
                                    { 
                                    Console.Clear();
                                    Console.WriteLine("Please Enter Your Account Number.");
                                    newAcc.accNo = Convert.ToInt32(Console.ReadLine());

                                    check = accObj.checkAccountExists(newAcc.accNo, newAcc.accEmail);
                                    if (check)
                                    {
                                        double chkBalance = accObj.CheckBalance(newAcc.accNo);
                                        Console.WriteLine("Current Balance is: " + "$" + chkBalance);
                                        Console.WriteLine("Please Enter Amount You Wish to Deposit.");
                                        double v_depositAmt = Convert.ToInt32(Console.ReadLine());
                                        if (v_depositAmt <= 0)
                                        {
                                            throw new Exception("Unable to process transaction. Must deposit more than $0");
                                        }
                                        double newAmt = tranObj.Deposit((Transactions)newAcc, v_depositAmt);
                                        Console.WriteLine("Deposit successful. Your new account balance is: " + "$" + newAmt);
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        throw new Exception("Account not found. Please re-enter account number.");
                                    }
                                    }
                                    catch (Exception es3)
                                    {
                                        Console.WriteLine(es3.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 4 : Perform Transfer
                                case 4:
                                    try
                                    { 
                                    Console.WriteLine("Which Account Would You Like to Transfer From? ");
                                    int v_fromAcc = Convert.ToInt32(Console.ReadLine());

                                    check = accObj.checkAccountExists(v_fromAcc, newAcc.accEmail);
                                    if (check)
                                    {
                                        double chkBalance = accObj.CheckBalance(v_fromAcc);
                                        Console.WriteLine("Your current Balance is: " + "$" + chkBalance);
                                        Console.WriteLine("Which Account Would You Like to Transfer To?");
                                        int v_toAcc = Convert.ToInt32(Console.ReadLine());
                                        check = accObj.checkAccountExists(v_toAcc, newAcc.accEmail);
                                        if (check)
                                        {
                                            double chkBalance2 = accObj.CheckBalance(v_toAcc);
                                            Console.WriteLine("Your current Balance is: " + "$" + chkBalance2);
                                            Console.WriteLine("Please Enter Amount You Wish to Transfer");
                                            int v_amount = Convert.ToInt32(Console.ReadLine());
                                            if (v_amount > chkBalance)
                                            {
                                                throw new Exception("Insufficient Funds to Process Transaction.");
                                            }
                                            if (v_amount <= 0)
                                            {
                                                throw new Exception("Unable to process transaction. Must transfer more than $0");
                                            }
                                            string tranAcc = tranObj.Transfer((Transactions)newAcc, v_fromAcc, v_toAcc, v_amount);
                                            Console.WriteLine(tranAcc);
                                            Console.ReadLine();
                                        }
                                        else
                                        {
                                            throw new Exception("Account not found. Please ensure your account number is correct and re-enter.");
                                        }
                                    }
                                    else
                                    {
                                        throw new Exception("Account not found. Please ensure your account number is correct and re-enter.");
                                    }
                                    }
                                    catch (Exception es4)
                                    {
                                        Console.WriteLine(es4.Message);
                                    }
                                    break;
                                    #endregion
                                #region Case 5 : View Last Transactions
                                case 5:
                                    try
                                    {
                                        Console.WriteLine("Please Verify an Account That You Own. ");
                                        newAcc.accNo = Convert.ToInt32(Console.ReadLine());

                                        check = accObj.checkAccountExists(newAcc.accNo, newAcc.accEmail);
                                        if (check)
                                        {
                                            List<Transactions> transList = tranObj.GetTransactionHistory(newAcc);
                                            foreach (var item in transList)
                                            {
                                                Console.WriteLine(" Transaction ID: " + item.tranID + "\n Date Transaction Occurred: " + item.tranDate + "\n Transaction Type: " + item.tranType + "\n From Account: " + item.fromAccount + "\n To Account: " + item.toAccount + "\n Transaction Amount: " + "$" + item.tranAmount + "\n Transaction Authorized by: " + item.completedBy);
                                                Console.WriteLine("-----------------------------------------------------");
                                            }
                                        }
                                        else
                                        {
                                            throw new Exception("Account not found. Please ensure you entered a correct account number.");
                                        }
                                    }
                                    catch (Exception es5)
                                    {
                                        Console.WriteLine(es5.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 6 : Change Password
                                case 6:
                                    try
                                    { 
                                    Console.WriteLine("Please Verify Username");
                                    newLog.userName = Console.ReadLine();
                                        if (string.IsNullOrEmpty(newLog.userName))
                                        {
                                            throw new Exception("No input from the user was recorded. Please input username.");
                                        }
                                        check = logObj.checkUserExists(newLog.userName);
                                    if (check)
                                    {
                                        Console.WriteLine("Please Enter New Password ");
                                        newLog.userPwd = Console.ReadLine();
                                            if (string.IsNullOrEmpty(newLog.userPwd))
                                            {
                                                throw new Exception("No input from the user was recorded. Please input new password.");
                                            }
                                            string updateResult = logObj.ChangePassword(newLog);
                                        Console.WriteLine(updateResult);
                                        Console.ReadLine();
                                    }
                                        else
                                        {
                                            throw new Exception("Unable to verify username. Please try again.");
                                        }
                                    }
                                    catch (Exception es6)
                                    {
                                        Console.WriteLine(es6.Message);
                                    }
                                    break;
                                #endregion
                                #region Case 7 : Exit
                                case 7:
                                    Console.WriteLine(" Thank You for Banking With Us, Goodbye. ");
                                    continueAPP2 = false;
                                    break;
                                #endregion
                                default:
                                    Console.WriteLine("That is Not a Valid Choice.");
                                    Console.ReadLine();
                                    break;
                            }
                            Console.ReadLine();
                            Console.Clear();
                        }
                        catch (Exception es)
                        {
                            Console.WriteLine(es.Message);
                        }
                        }
                        break;
                #endregion
            #region Welcome Menu Exit
                case 3:
                    Console.WriteLine("Thank You for Banking With Us, Goodbye. ");
                    break;
                #endregion
            #region Default Choice
                default:
                    Console.WriteLine("That is Not a Valid Choice.");
                    Console.ReadLine();
                    goto WelcomeMenu;
            }
                Console.Clear();
            #endregion
        }
    }
    }