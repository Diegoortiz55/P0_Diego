﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace LoginLIB
{
    public class LogInType
    {
        public string userName { get; set; }
        public string userPwd { get; set; }
        public string accountStatus { get; set; }
        public string userType { get; set; }
        public int loginAttempts { get; set; }

        SqlConnection con = new SqlConnection(@"server=localhost;database=BankingDB;user id=sa;password=Strong.Pwd-123;MultipleActiveResultSets=true");

        #region Check Admin Credentials
        public bool CheckAdminCredentials(string p_userName, string p_userPwd)
        {
            SqlCommand cmdCheckLogin = new SqlCommand("Select count(*) from tbl_LoginInfo where userName=@uName and userPwd=@uPwd and userType='Administrator'", con);
            cmdCheckLogin.Parameters.AddWithValue("@uName", p_userName);
            cmdCheckLogin.Parameters.AddWithValue("@uPwd", p_userPwd);
            con.Open();
            int v_CheckResult = Convert.ToInt32(cmdCheckLogin.ExecuteScalar());
            con.Close();

            if (v_CheckResult == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        #endregion

        #region Check User Credentials
        public string CheckUserCredentials(string p_userName, string p_userPwd)
        {
            SqlCommand cmdCheckLogin = new SqlCommand("Select count(*) from tbl_LoginInfo where userName=@uName and userType='User'", con);
            cmdCheckLogin.Parameters.AddWithValue("@uName", p_userName);
            con.Open();
            int chkLogin = Convert.ToInt32(cmdCheckLogin.ExecuteScalar());

            if (chkLogin == 1)
            {
                SqlCommand cmdCheckPassword = new SqlCommand("Select count(*) from tbl_LoginInfo where userName=@uName and userPwd=@uPwd", con);
                cmdCheckPassword.Parameters.AddWithValue("@uName", p_userName);
                cmdCheckPassword.Parameters.AddWithValue("@uPwd", p_userPwd);
                int chkpassword = Convert.ToInt32(cmdCheckPassword.ExecuteScalar());

                if (chkpassword == 0)
                {
                    SqlCommand cmdAttempts = new SqlCommand("select accountStatus,LoginAttempts from tbl_LoginInfo where userName=@uName", con);
                    cmdAttempts.Parameters.AddWithValue("@uName", p_userName);

                    SqlDataReader read = cmdAttempts.ExecuteReader();
                    if (read.Read())
                    {
                        string accountStatus = Convert.ToString(read[0]);
                        int loginAttempts = Convert.ToInt32(read[1]);
                        read.Close();

                        SqlCommand updateAccount;
                        if (loginAttempts == 2)
                        {
                            updateAccount = new SqlCommand("update tbl_LoginInfo set LoginAttempts=LoginAttempts+1, accountStatus='Disabled' where userName=@uName", con);
                        }
                        else
                        {
                            updateAccount = new SqlCommand("update tbl_LoginInfo set LoginAttempts=LoginAttempts+1 where userName=@uName", con);
                        }
                        updateAccount.Parameters.AddWithValue("@uName", p_userName);
                        updateAccount.ExecuteNonQuery();
                        con.Close();
                        return "Login Failed for User " + p_userName;
                    }
                }
                SqlCommand cmdStatus = new SqlCommand("select accountStatus from tbl_LoginInfo where userName=@uName", con);
                cmdStatus.Parameters.AddWithValue("@uName", p_userName);

                SqlDataReader read2 = cmdStatus.ExecuteReader();
                if (read2.Read())
                {
                    string accountStatus = Convert.ToString(read2[0]);
                    read2.Close();

                    if (accountStatus == "Disabled")
                    {
                        con.Close();
                        return "Account is disabled, please contact an Administrator";
                    }
                    if (accountStatus == "Active")
                    {
                        con.Close();
                        return "Login Successful";
                    }
                }
            }
            con.Close();
            return "user not found";
        }
        #endregion

        #region Change Password
        public string ChangePassword(LogInType p_logObj)
                {
                    SqlCommand cmdChangePassword = new SqlCommand("update tbl_LoginInfo set userPwd=@uPwd where userName=@uName", con);
                    cmdChangePassword.Parameters.AddWithValue("@uName", p_logObj.userName);
                    cmdChangePassword.Parameters.AddWithValue("@uPwd", p_logObj.userPwd);
                    if (p_logObj.userPwd.Length < 5 | p_logObj.userPwd.Length > 12)
                    {
                        throw new Exception("Password length must be more than 5 characters and less than 12");
                    }
                    con.Open();
                    int updateResult = cmdChangePassword.ExecuteNonQuery();
                    con.Close();
                    return "Password Changed Successfully";
                }
        #endregion

        #region Check If Account Exists
        public bool checkUserExists(string p_userName)
        {
            SqlCommand cmdCheck = new SqlCommand("Select count(*) from tbl_LoginInfo where userName=@uName", con);
            cmdCheck.Parameters.AddWithValue("@uName", p_userName);
            con.Open();
            int count = (int)cmdCheck.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Disable Account
        public string DisableAccount(LogInType p_logObj)
            {
                SqlCommand cmdDisableAccount = new SqlCommand("update tbl_LoginInfo set accountStatus='Disabled' where userName=@uname", con);
                cmdDisableAccount.Parameters.AddWithValue("@uName", p_logObj.userName);
                con.Open();
                int disableResult = cmdDisableAccount.ExecuteNonQuery();
                con.Close();
                if (disableResult > 0)
                {
                    return "Account has been disabled";
                }
                return "Account not found";
            }

            #endregion

        #region Activate Account
            public string EnableAccount(LogInType p_logObj)
            {
                SqlCommand cmdEnableAccount = new SqlCommand("update tbl_LoginInfo set accountStatus='Active',LoginAttempts=0 where userName=@uname", con);
                cmdEnableAccount.Parameters.AddWithValue("@uName", p_logObj.userName);
                con.Open();
                int enableResult = cmdEnableAccount.ExecuteNonQuery();
                con.Close();
                if (enableResult > 0)
                {
                    return "Account has been enabled";
                }
                return "Account not found";
            }
            #endregion
        }

    }


